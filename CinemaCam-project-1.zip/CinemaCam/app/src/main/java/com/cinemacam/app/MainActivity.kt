package com.cinemacam.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.cinemacam.app.gl.CinemaRenderThread

enum class CaptureMode { PHOTO, VIDEO }

class MainActivity : ComponentActivity() {

    private lateinit var cameraController: CameraController
    private var renderThread: CinemaRenderThread? = null
    private var videoRecorder: VideoRecorder? = null

    private var selectedPreset by mutableStateOf(FilterPresets.NATURAL_PLUS)
    private var captureMode by mutableStateOf(CaptureMode.PHOTO)
    private var isRecording by mutableStateOf(false)
    private var manualPanelOpen by mutableStateOf(false)
    private var controls by mutableStateOf(ManualControls())
    private var hasPermissions by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermissions = result.values.all { it }
        if (hasPermissions) startCameraPipeline()
        else Toast.makeText(this, "Нужны разрешения камеры и микрофона", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        cameraController = CameraController(this) { err ->
            runOnUiThread { Toast.makeText(this, err, Toast.LENGTH_LONG).show() }
        }

        setContent {
            MaterialTheme {
                CinemaCamUI()
            }
        }

        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val notGranted = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isEmpty()) {
            hasPermissions = true
            startCameraPipeline()
        } else {
            permissionLauncher.launch(notGranted.toTypedArray())
        }
    }

    /** Called once we have a real Surface from the SurfaceView to render into. */
    private fun onScreenSurfaceReady(surface: Surface, width: Int, height: Int) {
        if (!hasPermissions) return
        cameraController.start()

        renderThread = CinemaRenderThread(surface, width, height) { cameraTexture ->
            // Camera texture is ready on the GL thread - now open the camera and bind it.
            cameraController.openAndBuildSession(
                previewTexture = cameraTexture,
                recorderSurfaceForVideo = null
            ) {
                runOnUiThread {
                    renderThread?.setPreset(selectedPreset)
                }
            }
        }
        renderThread?.start()
    }

    private fun startCameraPipeline() {
        // Actual open happens once the SurfaceView reports its Surface (see onScreenSurfaceReady).
    }

    private fun onPresetSelected(preset: FilterPreset) {
        selectedPreset = preset
        renderThread?.setPreset(preset)
    }

    private fun onShutterPressed() {
        when (captureMode) {
            CaptureMode.PHOTO -> {
                cameraController.capturePhoto { image ->
                    PhotoProcessor.processAndSave(this, image, selectedPreset)
                    runOnUiThread {
                        Toast.makeText(this, "Фото сохранено", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            CaptureMode.VIDEO -> {
                if (!isRecording) startRecording() else stopRecording()
            }
        }
    }

    private fun startRecording() {
        val recorder = VideoRecorder(this)
        val size = cameraController.previewSize
        val surface = recorder.prepare(size)
        renderThread?.attachRecorderSurface(surface, size.width, size.height)
        recorder.start()
        videoRecorder = recorder
        isRecording = true
    }

    private fun stopRecording() {
        renderThread?.detachRecorderSurface()
        videoRecorder?.stop()
        Toast.makeText(this, "Видео сохранено: ${videoRecorder?.outputFile?.name}", Toast.LENGTH_LONG).show()
        videoRecorder = null
        isRecording = false
    }

    override fun onDestroy() {
        super.onDestroy()
        renderThread?.shutdown()
        cameraController.stop()
    }

    @Composable
    fun CinemaCamUI() {
        Box(Modifier.fillMaxSize()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val surfaceView = SurfaceView(ctx)
                    surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {}
                        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                            onScreenSurfaceReady(holder.surface, width, height)
                        }
                        override fun surfaceDestroyed(holder: SurfaceHolder) {}
                    })
                    FrameLayout(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        addView(surfaceView)
                    }
                }
            )

            // Top bar: mode toggle + manual controls button
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SegmentedModeSwitch(captureMode) { captureMode = it }
                IconToggle(manualPanelOpen) { manualPanelOpen = !manualPanelOpen }
            }

            if (manualPanelOpen) {
                ManualControlsPanel(
                    controls = controls,
                    isoRange = cameraController.availableIsoRangeOrDefault(),
                    supportsManual = cameraController.supportsManualSensor,
                    onChange = {
                        controls = it
                        cameraController.updateManualControls(it)
                    },
                    modifier = Modifier.align(Alignment.CenterEnd).padding(16.dp)
                )
            }

            // Bottom: filter carousel + shutter
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                FilterCarousel(selectedPreset, ::onPresetSelected)
                Spacer(Modifier.height(16.dp))
                ShutterButton(captureMode, isRecording, ::onShutterPressed)
            }
        }
    }

    @Composable
    fun SegmentedModeSwitch(mode: CaptureMode, onChange: (CaptureMode) -> Unit) {
        Row {
            listOf(CaptureMode.PHOTO to "Фото", CaptureMode.VIDEO to "Видео").forEach { (m, label) ->
                FilterChip(
                    selected = mode == m,
                    onClick = { onChange(m) },
                    label = { Text(label) },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }
    }

    @Composable
    fun IconToggle(open: Boolean, onClick: () -> Unit) {
        Button(onClick = onClick) {
            Text(if (open) "Скрыть ручные" else "Ручные настройки")
        }
    }

    @Composable
    fun FilterCarousel(selected: FilterPreset, onSelect: (FilterPreset) -> Unit) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(FilterPresets.ALL) { preset ->
                FilterChip(
                    selected = preset.id == selected.id,
                    onClick = { onSelect(preset) },
                    label = { Text(preset.displayName) }
                )
            }
        }
    }

    @Composable
    fun ShutterButton(mode: CaptureMode, recording: Boolean, onPress: () -> Unit) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Button(
                onClick = onPress,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (recording) Color.Red else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.size(76.dp),
                shape = androidx.compose.foundation.shape.CircleShape
            ) {
                Text(
                    when {
                        mode == CaptureMode.PHOTO -> "📷"
                        recording -> "■"
                        else -> "●"
                    }
                )
            }
        }
    }

    @Composable
    fun ManualControlsPanel(
        controls: ManualControls,
        isoRange: android.util.Range<Int>,
        supportsManual: Boolean,
        onChange: (ManualControls) -> Unit,
        modifier: Modifier = Modifier
    ) {
        Card(modifier = modifier.width(260.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Ручные настройки", style = MaterialTheme.typography.titleMedium)
                if (!supportsManual) {
                    Text(
                        "Этот сенсор поддерживает только автоэкспозицию, ручной ISO/выдержка недоступны",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Авто экспозиция")
                    Switch(
                        checked = controls.autoExposure,
                        onCheckedChange = { onChange(controls.copy(autoExposure = it)) }
                    )
                }
                if (!controls.autoExposure && supportsManual) {
                    Text("ISO: ${controls.isoValue}")
                    Slider(
                        value = controls.isoValue.toFloat(),
                        valueRange = isoRange.lower.toFloat()..isoRange.upper.toFloat(),
                        onValueChange = { onChange(controls.copy(isoValue = it.toInt())) }
                    )
                    val shutterFraction = (1_000_000_000f / controls.shutterNanos).toInt()
                    Text("Выдержка: 1/$shutterFraction c")
                    Slider(
                        value = controls.shutterNanos.toFloat(),
                        valueRange = 1_000_000f..500_000_000f,
                        onValueChange = { onChange(controls.copy(shutterNanos = it.toLong())) }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Автофокус")
                    Switch(
                        checked = controls.autoFocus,
                        onCheckedChange = { onChange(controls.copy(autoFocus = it)) }
                    )
                }
                if (!controls.autoFocus) {
                    Text("Фокус")
                    Slider(
                        value = controls.focusDistanceDiopters,
                        valueRange = 0f..10f,
                        onValueChange = { onChange(controls.copy(focusDistanceDiopters = it)) }
                    )
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Экспокоррекция")
                }
                Slider(
                    value = controls.exposureCompensation.toFloat(),
                    valueRange = -6f..6f,
                    onValueChange = { onChange(controls.copy(exposureCompensation = it.toInt())) }
                )
            }
        }
    }
}
