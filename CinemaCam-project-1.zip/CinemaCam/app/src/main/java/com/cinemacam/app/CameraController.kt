package com.cinemacam.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Surface
import kotlin.math.roundToInt

/**
 * Manual control state exposed to the UI. When `auto == true` the camera runs
 * its normal 3A (auto exposure/focus/white-balance) exactly like the stock
 * camera app; flipping a control to manual hands that single parameter to the
 * user without touching the others.
 */
data class ManualControls(
    val autoExposure: Boolean = true,
    val isoValue: Int = 400,              // used only when autoExposure == false
    val shutterNanos: Long = 1_000_000_000L / 60, // 1/60s default
    val autoFocus: Boolean = true,
    val focusDistanceDiopters: Float = 0f, // 0 = infinity
    val autoWhiteBalance: Boolean = true,
    val whiteBalanceKelvin: Int = 5500,
    val exposureCompensation: Int = 0
)

class CameraController(
    private val context: Context,
    private val onError: (String) -> Unit
) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private var cameraId: String = "0"
    var isoRange: Range<Int>? = null; private set
    var exposureTimeRangeNanos: Range<Long>? = null; private set
    var supportsManualSensor: Boolean = false; private set

    var previewSize: Size = Size(1920, 1080); private set
    var photoSize: Size = Size(3840, 2160); private set

    private var previewSurface: Surface? = null
    private var recorderSurface: Surface? = null
    private var imageReader: ImageReader? = null

    var manualControls = ManualControls()

    fun start() {
        backgroundThread = HandlerThread("CameraBg").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
        pickBackCamera()
    }

    fun stop() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
        } catch (_: InterruptedException) {
        }
        backgroundThread = null
        backgroundHandler = null
    }

    private fun pickBackCamera() {
        for (id in cameraManager.cameraIdList) {
            val chars = cameraManager.getCameraCharacteristics(id)
            val facing = chars.get(CameraCharacteristics.LENS_FACING)
            if (facing == CameraCharacteristics.LENS_FACING_BACK) {
                cameraId = id
                readCapabilities(chars)
                break
            }
        }
    }

    private fun readCapabilities(chars: CameraCharacteristics) {
        val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
        supportsManualSensor = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
        isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        exposureTimeRangeNanos = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)

        val map: StreamConfigurationMap? = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val jpegSizes = map?.getOutputSizes(android.graphics.ImageFormat.JPEG)
        photoSize = jpegSizes?.maxByOrNull { it.width.toLong() * it.height } ?: photoSize
        val previewSizes = map?.getOutputSizes(SurfaceTexture::class.java)
        // Cap preview at 1080p-ish for smooth real-time grading; A34 screen doesn't need more.
        previewSize = previewSizes
            ?.filter { it.width <= 1920 }
            ?.maxByOrNull { it.width.toLong() * it.height }
            ?: (previewSizes?.first() ?: previewSize)
    }

    @SuppressLint("MissingPermission")
    fun openAndBuildSession(
        previewTexture: SurfaceTexture,
        recorderSurfaceForVideo: Surface?,
        onSessionReady: () -> Unit
    ) {
        previewTexture.setDefaultBufferSize(previewSize.width, previewSize.height)
        previewSurface = Surface(previewTexture)
        recorderSurface = recorderSurfaceForVideo

        imageReader = ImageReader.newInstance(
            photoSize.width, photoSize.height, android.graphics.ImageFormat.JPEG, 2
        )

        cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) {
                cameraDevice = device
                createSession(onSessionReady)
            }

            override fun onDisconnected(device: CameraDevice) {
                device.close()
                cameraDevice = null
            }

            override fun onError(device: CameraDevice, error: Int) {
                device.close()
                cameraDevice = null
                onError("Camera error code $error")
            }
        }, backgroundHandler)
    }

    private fun createSession(onReady: () -> Unit) {
        val device = cameraDevice ?: return
        val surfaces = mutableListOf<Surface>()
        previewSurface?.let { surfaces.add(it) }
        imageReader?.surface?.let { surfaces.add(it) }
        recorderSurface?.let { surfaces.add(it) }

        device.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                startRepeatingPreview()
                onReady()
            }

            override fun onConfigureFailed(session: CameraCaptureSession) {
                onError("Failed to configure capture session")
            }
        }, backgroundHandler)
    }

    fun startRepeatingPreview() {
        val device = cameraDevice ?: return
        val session = captureSession ?: return
        val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
        previewSurface?.let { builder.addTarget(it) }
        recorderSurface?.let { builder.addTarget(it) }
        applyManualControls(builder)
        session.setRepeatingRequest(builder.build(), null, backgroundHandler)
    }

    /** Re-applies current ManualControls to the live repeating request (called on slider change). */
    fun updateManualControls(newControls: ManualControls) {
        manualControls = newControls
        startRepeatingPreview()
    }

    private fun applyManualControls(builder: CaptureRequest.Builder) {
        val mc = manualControls

        // Autofocus
        if (mc.autoFocus) {
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        } else {
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, mc.focusDistanceDiopters)
        }

        // Exposure (ISO + shutter) - only if device supports manual sensor control
        if (mc.autoExposure || !supportsManualSensor) {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            builder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, mc.exposureCompensation)
        } else {
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            isoRange?.let { range ->
                val clampedIso = mc.isoValue.coerceIn(range.lower, range.upper)
                builder.set(CaptureRequest.SENSOR_SENSITIVITY, clampedIso)
            }
            exposureTimeRangeNanos?.let { range ->
                val clampedShutter = mc.shutterNanos.coerceIn(range.lower, range.upper)
                builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, clampedShutter)
            }
        }

        // White balance
        if (mc.autoWhiteBalance) {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        } else {
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            // Approximate Kelvin -> gains isn't exposed directly pre-API33 without a color
            // transform; simplest reliable path is to leave AWB locked and let our GL
            // temperature/tint shader carry the manual white-balance look instead.
        }

        builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
    }

    fun capturePhoto(onImage: (Image) -> Unit) {
        val device = cameraDevice ?: return
        val session = captureSession ?: return
        val reader = imageReader ?: return

        reader.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            onImage(image)
        }, backgroundHandler)

        val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        builder.addTarget(reader.surface)
        applyManualControls(builder)
        builder.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
        session.capture(builder.build(), null, backgroundHandler)
    }

    fun availableIsoRangeOrDefault(): Range<Int> = isoRange ?: Range(100, 3200)
    fun availableShutterRangeOrDefault(): Range<Long> =
        exposureTimeRangeNanos ?: Range(1_000_000L, 1_000_000_000L)
}
