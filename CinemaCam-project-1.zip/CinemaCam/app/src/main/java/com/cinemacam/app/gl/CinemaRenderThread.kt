package com.cinemacam.app.gl

import android.graphics.SurfaceTexture
import android.opengl.EGLSurface
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import com.cinemacam.app.FilterPreset
import com.cinemacam.app.GLRenderer

/**
 * Owns the GL/EGL context on a dedicated thread. Every time a new camera
 * frame arrives it redraws it - graded with the active FilterPreset - onto
 * the screen, and (if a video recording is active) onto the recorder's input
 * surface as well, so the exported video carries exactly the look the user
 * saw live, at full native frame resolution.
 */
class CinemaRenderThread(
    private val screenSurface: Surface,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onCameraTextureReady: (SurfaceTexture) -> Unit
) {
    private val thread = HandlerThread("CinemaRenderThread")
    private lateinit var handler: Handler

    private val eglCore = EglCore()
    private val renderer = GLRenderer()
    private var screenEglSurface: EGLSurface? = null
    private var recorderEglSurface: EGLSurface? = null
    private var recorderWidth = 0
    private var recorderHeight = 0

    @Volatile private var recording = false

    fun start() {
        thread.start()
        handler = Handler(thread.looper)
        handler.post {
            eglCore.start()
            screenEglSurface = eglCore.createWindowSurface(screenSurface)
            eglCore.makeCurrent(screenEglSurface!!)
            renderer.setupGL()
            renderer.surfaceTexture?.setOnFrameAvailableListener {
                handler.post { drawFrame() }
            }
            renderer.surfaceTexture?.let { onCameraTextureReady(it) }
        }
    }

    fun setPreset(preset: FilterPreset) {
        renderer.currentPreset = preset
    }

    /** Call from the main/camera thread once a MediaRecorder surface is available. */
    fun attachRecorderSurface(surface: Surface, width: Int, height: Int) {
        handler.post {
            recorderEglSurface = eglCore.createWindowSurface(surface)
            recorderWidth = width
            recorderHeight = height
            recording = true
        }
    }

    fun detachRecorderSurface() {
        handler.post {
            recording = false
            recorderEglSurface?.let { eglCore.releaseSurface(it) }
            recorderEglSurface = null
        }
    }

    private fun drawFrame() {
        screenEglSurface?.let {
            eglCore.makeCurrent(it)
            renderer.drawFrame(screenWidth, screenHeight)
            eglCore.swapBuffers(it)
        }
        if (recording) {
            recorderEglSurface?.let {
                eglCore.makeCurrent(it)
                renderer.drawFrame(recorderWidth, recorderHeight)
                eglCore.swapBuffers(it)
            }
        }
    }

    fun shutdown() {
        handler.post {
            recorderEglSurface?.let { eglCore.releaseSurface(it) }
            screenEglSurface?.let { eglCore.releaseSurface(it) }
            eglCore.release()
            thread.quitSafely()
        }
    }
}
