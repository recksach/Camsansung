package com.cinemacam.app

import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Renders the camera's SurfaceTexture through a fragment shader that applies
 * the currently selected FilterPreset (color matrix + contrast + saturation +
 * white balance + vignette). The same shader/output is used both for the
 * on-screen preview AND for baking the look into recorded video, so what you
 * see while shooting is exactly what gets saved - true "what you see is what
 * you get" cinematic shooting.
 *
 * No resolution is ever downscaled here: the GL viewport always matches the
 * camera's native capture size, so detail is preserved (only color/tone is
 * graded, which is how real film LUTs work).
 */
class GLRenderer {

    private var program = 0
    private var textureId = -1
    var surfaceTexture: SurfaceTexture? = null
        private set

    @Volatile
    var currentPreset: FilterPreset = FilterPresets.NATURAL_PLUS

    private val triangleVertices: FloatBuffer
    private val stMatrix = FloatArray(16)

    private var uMVPMatrixHandle = 0
    private var uSTMatrixHandle = 0
    private var uColorMatrixHandle = 0
    private var uContrastHandle = 0
    private var uSaturationHandle = 0
    private var uTemperatureHandle = 0
    private var uTintHandle = 0
    private var uVignetteHandle = 0
    private var uResolutionHandle = 0
    private var aPositionHandle = 0
    private var aTexCoordHandle = 0

    private val mvpMatrix = FloatArray(16).also { Matrix.setIdentityM(it, 0) }

    companion object {
        private const val VERTEX_SHADER = """
            uniform mat4 uMVPMatrix;
            uniform mat4 uSTMatrix;
            attribute vec4 aPosition;
            attribute vec4 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = uMVPMatrix * aPosition;
                vTexCoord = (uSTMatrix * aTexCoord).xy;
            }
        """

        private const val FRAGMENT_SHADER = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTexCoord;
            uniform samplerExternalOES sTexture;
            uniform mat4 uColorMatrix;
            uniform float uContrast;
            uniform float uSaturation;
            uniform float uTemperature;
            uniform float uTint;
            uniform float uVignette;
            uniform vec2 uResolution;

            void main() {
                vec4 color = texture2D(sTexture, vTexCoord);

                // white balance push (temperature: blue<->orange, tint: green<->magenta)
                color.r = color.r + uTemperature * 0.12;
                color.b = color.b - uTemperature * 0.12;
                color.g = color.g + uTint * 0.06;

                // cinematic color-matrix grade (shadow/highlight color split)
                vec4 graded = uColorMatrix * vec4(color.rgb, 1.0);
                color.rgb = graded.rgb;

                // contrast around midpoint
                color.rgb = (color.rgb - 0.5) * uContrast + 0.5;

                // saturation
                float gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));
                color.rgb = mix(vec3(gray), color.rgb, uSaturation);

                // gentle vignette
                vec2 uv = (gl_FragCoord.xy / uResolution) - 0.5;
                float dist = dot(uv, uv);
                float vig = 1.0 - dist * uVignette * 1.6;
                color.rgb *= clamp(vig, 0.0, 1.0);

                gl_FragColor = vec4(clamp(color.rgb, 0.0, 1.0), 1.0);
            }
        """
    }

    init {
        val vertices = floatArrayOf(
            // x, y, z, u, v
            -1f, -1f, 0f, 0f, 0f,
            1f, -1f, 0f, 1f, 0f,
            -1f, 1f, 0f, 0f, 1f,
            1f, 1f, 0f, 1f, 1f
        )
        triangleVertices = ByteBuffer.allocateDirect(vertices.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        triangleVertices.put(vertices).position(0)
    }

    /** Call once, on the GL thread, after the EGL context is current. */
    fun setupGL(): Int {
        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        textureId = createExternalTexture()
        surfaceTexture = SurfaceTexture(textureId)

        aPositionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoord")
        uMVPMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        uSTMatrixHandle = GLES20.glGetUniformLocation(program, "uSTMatrix")
        uColorMatrixHandle = GLES20.glGetUniformLocation(program, "uColorMatrix")
        uContrastHandle = GLES20.glGetUniformLocation(program, "uContrast")
        uSaturationHandle = GLES20.glGetUniformLocation(program, "uSaturation")
        uTemperatureHandle = GLES20.glGetUniformLocation(program, "uTemperature")
        uTintHandle = GLES20.glGetUniformLocation(program, "uTint")
        uVignetteHandle = GLES20.glGetUniformLocation(program, "uVignette")
        uResolutionHandle = GLES20.glGetUniformLocation(program, "uResolution")

        return textureId
    }

    /** Draws one frame into whichever EGL surface is currently bound (screen or recorder). */
    fun drawFrame(viewportWidth: Int, viewportHeight: Int) {
        surfaceTexture?.updateTexImage()
        surfaceTexture?.getTransformMatrix(stMatrix)

        GLES20.glViewport(0, 0, viewportWidth, viewportHeight)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(program)

        triangleVertices.position(0)
        GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, 20, triangleVertices)
        GLES20.glEnableVertexAttribArray(aPositionHandle)

        triangleVertices.position(3)
        GLES20.glVertexAttribPointer(aTexCoordHandle, 2, GLES20.GL_FLOAT, false, 20, triangleVertices)
        GLES20.glEnableVertexAttribArray(aTexCoordHandle)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId)

        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uSTMatrixHandle, 1, false, stMatrix, 0)

        val preset = currentPreset
        GLES20.glUniformMatrix4fv(uColorMatrixHandle, 1, false, preset.matrix, 0)
        GLES20.glUniform1f(uContrastHandle, preset.contrast)
        GLES20.glUniform1f(uSaturationHandle, preset.saturation)
        GLES20.glUniform1f(uTemperatureHandle, preset.temperature)
        GLES20.glUniform1f(uTintHandle, preset.tint)
        GLES20.glUniform1f(uVignetteHandle, preset.vignette)
        GLES20.glUniform2f(uResolutionHandle, viewportWidth.toFloat(), viewportHeight.toFloat())

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPositionHandle)
        GLES20.glDisableVertexAttribArray(aTexCoordHandle)
    }

    private fun createExternalTexture(): Int {
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        val texId = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return texId
    }

    private fun createProgram(vertexSrc: String, fragmentSrc: String): Int {
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vertexShader)
        GLES20.glAttachShader(prog, fragmentShader)
        GLES20.glLinkProgram(prog)
        val linkStatus = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(prog)
            GLES20.glDeleteProgram(prog)
            throw RuntimeException("Could not link GL program: $log")
        }
        return prog
    }

    private fun loadShader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val compiled = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
        if (compiled[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw RuntimeException("Could not compile shader $type: $log")
        }
        return shader
    }
}
