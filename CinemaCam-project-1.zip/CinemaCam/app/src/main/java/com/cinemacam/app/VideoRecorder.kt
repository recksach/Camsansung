package com.cinemacam.app

import android.content.Context
import android.media.CamcorderProfile
import android.media.MediaRecorder
import android.os.Build
import android.util.Size
import android.view.Surface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * High-bitrate H.264/AAC recorder. Bitrate is set generously above the
 * platform default so the color grade (which adds subtle gradients/vignette)
 * doesn't introduce extra compression artifacts - quality goes up, not down.
 */
class VideoRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    var outputFile: File? = null
        private set

    fun prepare(size: Size, fps: Int = 30): Surface {
        val moviesDir = File(context.getExternalFilesDir(null), "CinemaCam")
        if (!moviesDir.exists()) moviesDir.mkdirs()
        val name = "CINEMA_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        outputFile = File(moviesDir, name)

        @Suppress("DEPRECATION")
        val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            MediaRecorder()
        }

        mr.setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
        mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
        mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
        mr.setOutputFile(outputFile!!.absolutePath)
        mr.setVideoEncodingBitRate(size.width * size.height * 10) // high bitrate, quality-first
        mr.setVideoFrameRate(fps)
        mr.setVideoSize(size.width, size.height)
        mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
        mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
        mr.setAudioSamplingRate(48000)
        mr.setAudioEncodingBitRate(256_000)
        mr.prepare()

        recorder = mr
        return mr.surface
    }

    fun start() {
        recorder?.start()
    }

    fun stop() {
        try {
            recorder?.stop()
        } catch (_: Exception) {
            // ignore - can throw if stopped too soon after start
        }
        recorder?.reset()
        recorder?.release()
        recorder = null
    }
}
