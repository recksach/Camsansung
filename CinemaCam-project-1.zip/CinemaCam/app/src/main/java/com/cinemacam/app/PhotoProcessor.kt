package com.cinemacam.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.Image
import android.os.Build
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Applies the same look used for the live preview to the full-resolution
 * still capture, then saves it at maximum JPEG quality (100). We never
 * downscale or resample the image - only color values are transformed - so
 * resolution and detail are identical to (or better graded than) the stock
 * camera output.
 */
object PhotoProcessor {

    fun processAndSave(context: Context, image: Image, preset: FilterPreset) {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        image.close()

        val original = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        val graded = applyGrade(original, preset)

        val name = "CINEMA_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        saveToGallery(context, graded, name)

        original.recycle()
        graded.recycle()
    }

    private fun applyGrade(src: Bitmap, preset: FilterPreset): Bitmap {
        val result = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)

        // Convert our 4x4 shader matrix + contrast/saturation into an Android
        // ColorMatrix pipeline (Android's ColorMatrix is a 4x5 row-major matrix).
        val cm = ColorMatrix()

        val gradeMatrix = ColorMatrix(
            floatArrayOf(
                preset.matrix[0], preset.matrix[4], preset.matrix[8], 0f, 0f,
                preset.matrix[1], preset.matrix[5], preset.matrix[9], 0f, 0f,
                preset.matrix[2], preset.matrix[6], preset.matrix[10], 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(gradeMatrix)

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(preset.saturation)
        cm.postConcat(saturationMatrix)

        val c = preset.contrast
        val translate = (1f - c) * 128f
        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, translate,
                0f, c, 0f, 0f, translate,
                0f, 0f, c, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(contrastMatrix)

        val temp = preset.temperature * 30f
        val tint = preset.tint * 15f
        val wbMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, temp,
                0f, 1f, 0f, 0f, tint,
                0f, 0f, 1f, 0f, -temp,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(wbMatrix)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(src, 0f, 0f, paint)

        if (preset.vignette > 0f) {
            drawVignette(canvas, result.width, result.height, preset.vignette)
        }

        return result
    }

    private fun drawVignette(canvas: Canvas, w: Int, h: Int, strength: Float) {
        val radius = kotlin.math.hypot(w / 2f, h / 2f)
        val shader = android.graphics.RadialGradient(
            w / 2f, h / 2f, radius,
            intArrayOf(0x00000000, (strength * 140).toInt().coerceIn(0, 180) shl 24),
            floatArrayOf(0.55f, 1f),
            android.graphics.Shader.TileMode.CLAMP
        )
        val paint = Paint()
        paint.shader = shader
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
    }

    private fun saveToGallery(context: Context, bitmap: Bitmap, filename: String) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CinemaCam")
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return
        val out: OutputStream = resolver.openOutputStream(uri) ?: return
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
        out.flush()
        out.close()
    }
}
