package com.cinemacam.app

/**
 * Each preset describes a full "look" - inspired by the color grading language
 * of contemporary film styles (not a copy of any specific movie, just the same
 * grading grammar: shadow/highlight color splits, contrast curve, saturation,
 * white balance push, and a light vignette).
 *
 * matrix = 4x4 color matrix applied in the shader. It stays close to identity
 * so the sensor's real resolution/detail is preserved - we grade color,
 * we don't soften or destroy detail.
 */
data class FilterPreset(
    val id: String,
    val displayName: String,
    val description: String,
    val matrix: FloatArray,       // 16 floats, column-major 4x4
    val contrast: Float,          // 1.0 = neutral
    val saturation: Float,        // 1.0 = neutral
    val temperature: Float,       // -1..1 (blue..orange)
    val tint: Float,              // -1..1 (green..magenta)
    val vignette: Float,          // 0..1 strength
    val shadowsLift: Float = 0f,      // -0.05..0.05 lifts/crushes blacks
    val highlightsRolloff: Float = 0f // 0..0.1 softens clipped highlights
)

object FilterPresets {

    private val IDENTITY = floatArrayOf(
        1f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f,
        0f, 0f, 1f, 0f,
        0f, 0f, 0f, 1f
    )

    val NATURAL_PLUS = FilterPreset(
        id = "natural_plus",
        displayName = "Natural+",
        description = "Чистая картинка с сенсора: лёгкий контраст и насыщенность, без искажений",
        matrix = IDENTITY,
        contrast = 1.06f,
        saturation = 1.08f,
        temperature = 0.02f,
        tint = 0f,
        vignette = 0.05f
    )

    val BLOCKBUSTER = FilterPreset(
        id = "blockbuster",
        displayName = "Blockbuster",
        description = "Большой студийный боевик: бирюзовые тени, оранжевая кожа, плотный контраст",
        matrix = floatArrayOf(
            1.08f, 0f, 0.04f, 0f,
            0f, 1.0f, 0.02f, 0f,
            0.02f, 0.08f, 0.92f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.18f,
        saturation = 1.15f,
        temperature = 0.12f,
        tint = -0.02f,
        vignette = 0.22f,
        shadowsLift = -0.02f
    )

    val INDIE_MUTED = FilterPreset(
        id = "indie_muted",
        displayName = "Indie Muted",
        description = "Приглушённые пастельные тона независимого авторского кино",
        matrix = floatArrayOf(
            0.96f, 0.02f, 0.02f, 0f,
            0.03f, 0.95f, 0.02f, 0f,
            0.02f, 0.02f, 0.94f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 0.94f,
        saturation = 0.78f,
        temperature = -0.03f,
        tint = 0.04f,
        vignette = 0.08f,
        shadowsLift = 0.03f
    )

    val COLD_STEEL = FilterPreset(
        id = "cold_steel",
        displayName = "Cold Steel",
        description = "Холодный стальной триллер/техно-нуар: синие тени, жёсткий контраст",
        matrix = floatArrayOf(
            0.95f, 0f, 0.03f, 0f,
            0f, 0.98f, 0.04f, 0f,
            0.05f, 0.05f, 1.08f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.22f,
        saturation = 0.7f,
        temperature = -0.18f,
        tint = -0.02f,
        vignette = 0.28f,
        shadowsLift = -0.03f
    )

    val GOLDEN_HOUR = FilterPreset(
        id = "golden_hour",
        displayName = "Golden Hour",
        description = "Тёплая плёночная палитра для портретов и заката, мягкие блики",
        matrix = floatArrayOf(
            1.06f, 0.02f, 0f, 0f,
            0.02f, 1.02f, 0f, 0f,
            0f, 0f, 0.9f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.04f,
        saturation = 1.1f,
        temperature = 0.22f,
        tint = 0.03f,
        vignette = 0.15f,
        highlightsRolloff = 0.04f
    )

    val NEO_NOIR = FilterPreset(
        id = "neo_noir",
        displayName = "Neo-Noir",
        description = "Зелёно-бирюзовый мрачный нуар с проваленными тенями и высокой резкостью контраста",
        matrix = floatArrayOf(
            0.9f, 0.02f, 0f, 0f,
            0.04f, 1.02f, 0.02f, 0f,
            0f, 0.04f, 0.94f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.28f,
        saturation = 0.65f,
        temperature = -0.06f,
        tint = 0.05f,
        vignette = 0.32f,
        shadowsLift = -0.04f
    )

    val PASTEL_SYMMETRY = FilterPreset(
        id = "pastel_symmetry",
        displayName = "Pastel Symmetry",
        description = "Яркие книжные пастельные тона в духе симметричных артхаусных комедий",
        matrix = floatArrayOf(
            1.04f, 0.02f, 0.02f, 0f,
            0.02f, 1.0f, 0.03f, 0f,
            0.03f, 0.02f, 0.98f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.02f,
        saturation = 1.25f,
        temperature = 0.06f,
        tint = 0.08f,
        vignette = 0.04f
    )

    val CLASSIC_BW = FilterPreset(
        id = "classic_bw",
        displayName = "Classic Noir B&W",
        description = "Контрастная чёрно-белая плёночная классика с мягким зерном по краям",
        matrix = floatArrayOf(
            0.33f, 0.33f, 0.33f, 0f,
            0.59f, 0.59f, 0.59f, 0f,
            0.11f, 0.11f, 0.11f, 0f,
            0f, 0f, 0f, 1f
        ),
        contrast = 1.35f,
        saturation = 0.0f,
        temperature = 0f,
        tint = 0f,
        vignette = 0.30f,
        shadowsLift = -0.03f
    )

    val ALL: List<FilterPreset> = listOf(
        NATURAL_PLUS,
        BLOCKBUSTER,
        INDIE_MUTED,
        COLD_STEEL,
        GOLDEN_HOUR,
        NEO_NOIR,
        PASTEL_SYMMETRY,
        CLASSIC_BW
    )

    fun byId(id: String): FilterPreset = ALL.firstOrNull { it.id == id } ?: NATURAL_PLUS
}
